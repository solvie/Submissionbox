//definition of the node class
public class node {

	public String element;  //data
	public node next;   //pointing to the next node
}
